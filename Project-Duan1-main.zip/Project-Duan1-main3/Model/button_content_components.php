<a class="collapse-item" href="?action=admin_product">
    <div class="flex gap-3">
        <span>Sản phẩm</span>
    </div>
</a>

<a class="collapse-item" href="?action=admin_category">
    <div class="flex gap-3">
        <span>Danh mục</span>
    </div>
</a>

<a class="collapse-item" href="?action=admin_coupon">
    <div class="flex gap-3">
        <span>Mã giảm giá</span>
    </div>
</a>

<a class="collapse-item" href="?action=admin_blog">
    <div class="flex gap-3">
        <span>Bài đăng</span>
    </div>
</a>

<a class="collapse-item" href="?action=admin_blog_category">
    <div class="flex gap-3">
        <span>Danh mục bài đăng</span>
    </div>
</a>

<a class="collapse-item" href="?action=admin_order">
    <div class="flex gap-3">
        <span>Đơn hàng</span>
    </div>
</a>