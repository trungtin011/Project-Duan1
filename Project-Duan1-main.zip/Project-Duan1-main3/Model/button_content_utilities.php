<a class="collapse-item" href="?action=admin_color">
    <div class="flex gap-3">
        <span>Màu sắc</span>
    </div>
</a>

<a class="collapse-item" href="?action=admin_size">
    <div class="flex gap-3">
        <span>Kích cỡ</span>
    </div>
</a>
