<?php 
    header('Location: Controller/index.php');
?>