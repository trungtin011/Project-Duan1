<?php 
    $ROOT_URL = "/Project-Duan1-mai";
    $CONTENT_URL = "$ROOT_URL/View";
    $MODAL_URL = "$ROOT_URL/Modal";
    $CONTROLLER_URL = "$ROOT_URL/Controller";
    $CSS_URL = "$ROOT_URL/css";
?>